package com.ar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApocalypseResistanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
