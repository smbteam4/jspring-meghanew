package com.ar.bo;

public class ReportsBo {
	
	private SurvivorReportBo survivorReportBo;
	private RobotsReportBo robotsReportBo;
	
	public SurvivorReportBo getSurvivorReportBo() {
		return survivorReportBo;
	}
	public void setSurvivorReportBo(SurvivorReportBo survivorReportBo) {
		this.survivorReportBo = survivorReportBo;
	}
	public RobotsReportBo getRobotsReportBo() {
		return robotsReportBo;
	}
	public void setRobotsReportBo(RobotsReportBo robotsReportBo) {
		this.robotsReportBo = robotsReportBo;
	}
	
	
	
	

}
