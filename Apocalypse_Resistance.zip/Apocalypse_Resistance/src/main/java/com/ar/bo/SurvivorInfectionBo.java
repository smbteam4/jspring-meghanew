package com.ar.bo;


public class SurvivorInfectionBo {
	
	private int  iSurvivorId;
	private boolean blIsInfected;
	
	public int getiSurvivorId() {
		return iSurvivorId;
	}
	public void setiSurvivorId(int iSurvivorId) {
		this.iSurvivorId = iSurvivorId;
	}
	public boolean isBlIsInfected() {
		return blIsInfected;
	}
	public void setBlIsInfected(boolean blIsInfected) {
		this.blIsInfected = blIsInfected;
	}

	
	
	

}
